require "application_system_test_case"

class MicropostsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit microposts_url
  #
  #   assert_selector "h1", text: "Micropost"
  # end
end
